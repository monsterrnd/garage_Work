<?
/**
* таблица для работы с базой
*/	
class CAdminElement 
{

}