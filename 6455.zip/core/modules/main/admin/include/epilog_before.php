<?php
include_once($_SERVER["DOCUMENT_ROOT"].ROOT."/admin/templates/footer.php");
