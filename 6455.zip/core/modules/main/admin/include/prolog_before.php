<?php
define("START_PROLOG_AFTER", "Y");
require_once($_SERVER["DOCUMENT_ROOT"]."/core/modules/main/admin/include/prolog.php");