<?
require_once(__DIR__ ."/../../root.php");
require_once(__DIR__ ."/../classes/NotAutoload.php");
if (START_PROLOG_AFTER != "Y")
{
	require($_SERVER["DOCUMENT_ROOT"].ROOT."/modules/main/admin/include/prolog_after.php");
}