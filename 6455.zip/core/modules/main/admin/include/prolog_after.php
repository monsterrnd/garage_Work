<?
include_once($_SERVER["DOCUMENT_ROOT"].ROOT."/admin/templates/header.php");
?>