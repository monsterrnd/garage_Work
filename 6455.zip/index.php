<?define("TITLE_PANEL","События");?>
<?require($_SERVER["DOCUMENT_ROOT"]."/core/header.php");?>

<?require($_SERVER["DOCUMENT_ROOT"]."/core/footer.php");?>