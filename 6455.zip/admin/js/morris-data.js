$(function() {

    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2016-01',
            company: 1,
            user: 5
        }, {
            period: '2016-02',
            company: 3,
            user: 20
        }, {
            period: '2016-03',
            company: 5,
            user: 43
        }, {
            period: '2016-04',
            company: 12,
            user: 232
        }, {
            period: '2016-05',
            company: 15,
            user: 322
        }],
        xkey: 'period',
        ykeys: ['company', 'user'],
        labels: ['Компании', 'Пользователи'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Download Sales",
            value: 12
        }, {
            label: "In-Store Sales",
            value: 30
        }, {
            label: "Mail-Order Sales",
            value: 20
        }],
        resize: true
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: '2006',
            a: 100,
            b: 90
        }, {
            y: '2007',
            a: 75,
            b: 65
        }, {
            y: '2008',
            a: 50,
            b: 40
        }, {
            y: '2009',
            a: 75,
            b: 65
        }, {
            y: '2010',
            a: 50,
            b: 40
        }, {
            y: '2011',
            a: 75,
            b: 65
        }, {
            y: '2012',
            a: 100,
            b: 90
        }],
        xkey: 'y',
        ykeys: ['a', 'b'],
        labels: ['Series A', 'Series B'],
        hideHover: 'auto',
        resize: true
    });
    
});
